module.exports = {
    plugins: {
        'postcss-import': {},
        autoprefixer: {},
        "@tailwindcss/postcss": {}
    }
}