import React from 'react'

export const CustomButton = () => {
    return (
        <div>CustomButton</div>
    )
}
